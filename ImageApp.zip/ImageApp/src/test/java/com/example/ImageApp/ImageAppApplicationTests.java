package com.example.ImageApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
