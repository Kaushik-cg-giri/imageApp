//package com.example.ImageApp.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import com.example.ImageApp.entity.user;
//import com.example.ImageApp.service.uesrService;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class userController {
//	@Autowired
//	public uesrService userService;
//
//	@PostMapping("/add/user")
//	public String addUser(@RequestBody user user) {
//		return userService.adduser(user);
//	}
//
//}
