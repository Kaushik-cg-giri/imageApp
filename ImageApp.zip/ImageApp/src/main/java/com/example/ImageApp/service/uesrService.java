//package com.example.ImageApp.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//import com.example.ImageApp.repository.imageAppRepository;
//import com.example.ImageApp.entity.user;
//
//
//@Service
//public class uesrService {
//
//	@Autowired
//	public  imageAppRepository imageAppRepository;
//	@Autowired
//	//public PasswordEncoder passwordEncoder;
//
//	public  String adduser(user user) {
//		// TODO Auto-generated method stub
//		user user1 =imageAppRepository.save(user);
//		//user.setPassword(passwordEncoder.encode(user.getPassword()));
//
//		return "Sucessfully added";
//	}
//
//}
